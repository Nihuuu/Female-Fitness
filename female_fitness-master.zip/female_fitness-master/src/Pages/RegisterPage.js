import React from 'react'
import { Register } from '../Component/Register'

export const RegisterPage = () => {
  return (
    <Register />
  )
}
