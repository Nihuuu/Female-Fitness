import React from 'react'
import Home from '../Component/Home'

export const HomePage = () => {

  return (
    <Home />
  )
}
