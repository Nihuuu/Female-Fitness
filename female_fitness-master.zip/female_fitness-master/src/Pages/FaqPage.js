import React from 'react'
import {Faq} from '../Component/Faq'
export const FaqPage = () => {
  return (
    <><Faq /></>
  )
}
