import React from 'react'
import {PlanFrom} from '../Component/PlanForm'
export const PlanFromPage = () => {
  return (
    <>
    <PlanFrom />
    </>
  )
}
