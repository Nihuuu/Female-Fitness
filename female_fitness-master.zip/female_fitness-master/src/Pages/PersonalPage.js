import React from 'react'
import { Personal } from '../Component/Personal'

const PersonalPage = () => {
  return (
    <Personal />
  )
}

export default PersonalPage
