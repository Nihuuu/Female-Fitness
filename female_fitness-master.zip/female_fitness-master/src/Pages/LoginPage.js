import React from 'react'
import { Login } from '../Component/Login'
export const LoginPage = () => {
  return (
    <Login />
  )
}
