import React from 'react'
import {Feedback} from '../Component/Feedback'
export const FeedbackPage = () => {
  return (
    <><Feedback /></>
  )
}
