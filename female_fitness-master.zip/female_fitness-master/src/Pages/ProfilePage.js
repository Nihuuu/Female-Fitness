import React from 'react'
import { Profile } from '../Component/Profile'
export const ProfilePage = () => {
  return (
    <Profile />
  )
}
