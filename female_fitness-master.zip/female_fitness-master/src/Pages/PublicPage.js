import React from 'react'
import { Public } from '../Component/Public'
export const PublicPage = () => {
  return (
    <Public />
  )
}
