//diet 

const Day1=[
    {name :'Drink hot water with lemon juice and honey 1 glass'},
    {name :'Have oats porridge with skimmed milk (1 bowl). Add some nuts 25gm'},
    {name :'Vegetable Salad 1 bowl'},
    {name :'1 small bowl dal, 1 chapati, green vegetable 1 small bowl'},
    {name :'1 bowl seasonal fruits and butter milk'},
    {name :'1 bowl dal, 1 roti, 1 small bowl bottle guard vegetable'},
  
  ];
  const Day2=[
    {name :'Skim Milk Yoghurt (1 cup) Multigrain paratha (1 toast)'},
    {name :'Soya Paneer (100 grams)'},
    {name :'Mixed Vegetable Salad (1 bowl)'},
    {name :'Sauteed Paneer (1 bowl) Roti (1 chapati) Mint Chutney (2 tablespoon)'},
    {name :'Banana (small) Buttermilk (1 glass)'},
    {name :'Moong Lentil Curry (0.75 bowl) Palak Rice (0.5 bowl)'},
  ];
  const Day3=[
    {name :'Skimmed Milk (1 glass) Peas upma (1.5 bowl)'},
    {name :'Low fat Milk Paneer (100 grams)'},
    {name :'Mixed Vegetable Salad (1 bowl)'},
    {name :'Muskmelon (1 cup 1″ pieces) Buttermilk (1 glass)'},
    {name :'Black Tea with Less Sugar and Milk (1 teacup)'},
    {name :'Curd (1.5 bowl) Aloo peas Tomato vegetable (1 bowl) Ragi Roti (1 roti/chapati)'},
  
  ];
  const Day4=[
    {name :'Low fat Curd (1.5 bowl) onion Stuffed Roti (2 pieces)'},
    {name :'Mixed Vegetable Salad (1 bowl)'},
    {name :'Moong Lentil Curry (0.75 bowl) Brown Rice (0.5 bowl)'},
    {name :'Green Apple (half) Buttermilk (1 glass)'},
    {name :'Black Coffee with Milk and Less Sugar (0.5 teacup)'},
    {name :'Sauteed leafy Vegetables with Paneer (1 bowl) Bajra Roti (1 roti/chapati) Coriander Chutney (2 tablespoon)'},
  ];
  const Day5=[
    {name :'Suji Chilla (1 cheela) Mint Garlic Chutney (2 tablespoon)'},
    {name :'Mixed Vegetable Salad (1 bowl)'},
    {name :'Palak Corn (1 bowl) Steamed brown Rice (0.5 bowl)'},
    {name :'Coffee with No Sugar and less Milk (1 teacup)'},
    {name :'Mixed Vegetable Salad (1 bowl)'},
    {name :'Skimmed milk Paneer Curry (1 bowl) vegetable Roti (1 roti)'},
  ];
  const Day6=[
    {name :'Hot water with lemon juice and honey (1 glass)'},
    {name :'Low fat Milk Yoghurt (1 bowl) Brown bread Toast (2 toast)'},
    {name :'Mixed Vegetable Salad (1 bowl)'},
    {name :'Palak corn (1 bowl) Roti (1 roti/chapati) Mint curd Chutney (2 tablespoon)'},
    {name :'Black Coffee with Less Sugar (1 teacup)'},
    {name :'Moong Lentil Curry (0.75 bowl) Chana palak Rice (0.5 bowl)'},
  ];
  
  export const Data = {
  
    Day1,
    Day2,
    Day3,
    Day4,
    Day5,
    Day6,

  };
  